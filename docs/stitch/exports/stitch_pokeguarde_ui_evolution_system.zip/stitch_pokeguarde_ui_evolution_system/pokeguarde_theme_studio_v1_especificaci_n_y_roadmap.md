# POKEGUARDE — THEME STUDIO V1 (Admin Suite)
### Arquitectura y Especificación Técnica del Gestor Global de Temas y Design System

Se ha estructurado la integración del **Theme Studio** dentro de la suite administrativa de Pokeguarde, manteniendo plena fidelidad con el dashboard técnico canónico (`MODEL: PKG-02 SILVER EDITION`, Pocket Tech 1999, paleta `#fff9ec` / `#faf3e2` / `#d93636` / `#1c1a1a`, tipografía *Space Mono* / *Space Grotesk* y dobles bordes mecánicos estilo GBC).

---

### 1. Integración en el Dashboard de Pokeguarde
- **Barra Superior Canónica**: Identificación de hardware, estado de alimentación, entrenador (`RED`), saldo de Guardipuntos y credencial de administrador `[AUTH: 0xADMIN_SYS]`.
- **Navegación Lateral (Sidebar)**:
  - Módulos de Usuario: Guardería, Ficha / Datos, Equipo Activo, Jugadores, Crianza & Huevos, Biblioteca, Tienda & Decoración.
  - **Sección Privilegiada (ADMIN SUITE)**:
    - 🔒 `MARKETING STUDIO` (13 módulos de divulgación y assets).
    - 🎨 `THEME STUDIO` (Nuevo módulo administrativo para personalización global de tokens y temas).

---

### 2. Los 5 Temas Predefinidos (Presets Globales)
1. **THEME 01 — POKÉGUARDE CLASSIC (Activo)**: El estándar Pocket Tech 1999 (marfil cálido, rojo Pokéball `#d93636`, carbón `#1c1a1a`, toques cian y dorado).
2. **THEME 02 — POKÉGUARDE DARK**: Carbón profundo (`#121413`), superficies grafito (`#1a1f1b`), acento rojo vivo y tipografía de alto contraste.
3. **THEME 03 — RETRO LCD**: Fondo verde dot-matrix estilo Game Boy Pocket/Color (`#c6cca5` / `#8b956d`), tinta oliva oscura (`#1f2416`), micro-pixel text y estética monocroma industrial.
4. **THEME 04 — POKÉGUARDE MINIMAL**: Blanco suizo puro (`#ffffff`), grises neutros rigurosos, acento rojo ultra-delgado (1px) y espaciado editorial suizo.
5. **THEME 05 — POKÉGUARDE MODERN**: Blanco hielo y azul grisáceo suave (`#f0f4f8` / `#e2e8f0`), acento coral cálido (`#ff5252`), sombras suaves difusas y bordes redondeados.

---

### 3. Vistas Principales del Theme Studio
- **Pantalla Maestra / Overview & Theme Gallery**: 4 KPI cards de control de temas, acciones de importación/exportación de tokens y galería visual interactiva de los 5 temas con previsualizador en vivo.
- **Editor Tri-Panel (Theme Studio Workspace)**: Panel izquierdo de categorías (Colores, Tipografía, Espaciado, Componentes), lienzo central con previsualizador multipantalla (Homepage, Guardería, Ficha, Biblioteca) e inspector derecho de propiedades de tokens.
- **Design Token Manager & Matriz DESIGN.md**: Editor tabular de tokens semánticos con resolución de herencias y exportación a CSS Variables, JSON Tokens y Tailwind Config.
- **Workflow de Activación Global & Seguridad**: Pantalla de auditoría de contraste WCAG, confirmación de despliegue a producción y pantalla de acceso restringido (403).
