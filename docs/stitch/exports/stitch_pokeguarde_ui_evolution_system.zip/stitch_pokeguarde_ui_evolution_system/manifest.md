# MANIFEST.md — POKEGUARDE MISIÓN STITCH-EXPORT-01
**Auditoría y Exportación de las 12 Pantallas Declaradas**  
**Proyecto Google Stitch ID:** `11971189356527444727`  
**Documento Base:** `POKEGUARDE — RESUMEN FINAL Y CHECKLIST DE IMPLEMENTACIÓN`  
**Sistema de Diseño:** *Pocket Tech 1999*  
**Fecha de Auditoría:** 2026-11-20  

---

## 1. Resumen General de Auditoría

| Métrica | Cantidad | Detalle |
| :--- | :---: | :--- |
| **Pantallas Declaradas** | **12** | Catálogo definido en el informe de entrega. |
| **Pantallas Verificadas Existentes** | **12** | Localizadas en el DataStore y Canvas de la sesión activa de Stitch. |
| **Exportaciones Completas** | **0** | Requiere empaquetado zip final y URLs públicas directas independientes. |
| **Exportaciones Parciales** | **12** | Código HTML/JS, especificación DESIGN.md y capturas renderizadas disponibles. |
| **Pantallas Encontradas Sin Exportar**| **0** | Todas las 12 cuentan con sus artefactos primarios en DataStore. |
| **Pantallas No Encontradas** | **0** | Ninguna pantalla del catálogo está ausente en el proyecto. |
| **Pantallas No Verificables** | **0** | Se ha accedido y comprobado el árbol completo del proyecto. |

---

## 2. Inventario Individual y Correspondencias Nativa Stitch

| ID Declarado | ID Nativo Stitch | Título Original Verificado | Shell Asociado | Estado | Formato |
| :--- | :--- | :--- | :--- | :---: | :---: |
| **SCREEN_25** | `SCREEN_26` | `Guardería (2/2 Pokémon) — Escritorio` | `SHELL_27` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_23** | `SCREEN_24` | `Ficha / Datos — Manaphy Visitante & Permisos` | `SHELL_25` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_21** | `SCREEN_22` | `Directorio de Jugadores & Guarderías Compartidas` | `SHELL_23` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_19** | `SCREEN_20` | `Crianza & Huevos — Selección de Pareja & Validación Biológica` | `SHELL_21` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_17** | `SCREEN_18` | `Crianza & Huevos — Entrega de 2 Huevos & Incubación con GP` | `SHELL_19` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_15** | `SCREEN_16` | `Crianza & Huevos — Secuencia de Eclosión Phione` | `SHELL_17` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_13** | `SCREEN_14` | `Crianza & Huevos — Animación Interactiva de Eclosión Phione` | `SHELL_15` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_10** | `SCREEN_11` | `Tienda de Guardipuntos (GP) & Editor de Decoración` | `SHELL_12` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_8** | `SCREEN_9` | `Perfil de Jugador, Notificaciones & Privacidad` | `SHELL_10` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_6** | `SCREEN_7` | `Biblioteca — Equipo Activo & Mochila` | `SHELL_8` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_4** | `SCREEN_5` | `Biblioteca — Cajas de PC (1-14) & Filtros de Legalidad` | `SHELL_6` | EXPORTADA PARCIAL | Desktop (1440×900) |
| **SCREEN_2** | `SCREEN_3` | `Inspección Forense — Detalle de Legalidad PKHeX (Celebi GS-Ball)` | `SHELL_4` | EXPORTADA PARCIAL | Desktop (1440×900) |

> **Nota sobre discrepancia de IDs:** Los identificadores citados en el informe técnico original (`SCREEN_25`...`SCREEN_2`) corresponden a la correlación lógica declarada por el usuario. En el DataStore de Google Stitch, cada guardado genera identificadores del tipo `SCREEN_N` donde N se incrementó correlativamente durante la creación del proyecto (`SCREEN_26`, `SCREEN_24`, etc.).

---

## 3. Correspondencia con Diseños y Referencias Locales Anteriores

1. **`guarderia-desktop` (Versión 5 previa, ZIP SHA256 `219b...`):**
   - **Estado:** CORRESPONDENCIA VERIFICADA (Evolucionada).
   - **Análisis:** La pantalla nativa `SCREEN_26` es la evolución directa de esta referencia previa: mantiene la carcasa ovalada roja, pero amplía la capacidad de 1 a 2 Pokémon con el protocolo de estancia compartida.
2. **`ficha-desktop` (Versión 7 previa) y `ficha-mobile` (Versión 6 previa):**
   - **Estado:** CORRESPONDENCIA VERIFICADA (Evolucionada).
   - **Análisis:** La pantalla nativa `SCREEN_24` adopta la estructura de ficha de datos pero adaptada al espécimen visitante Manaphy y los 3 permisos delegados.
3. **Cinco Variantes Adicionales Locales sin ID:**
   - **Estado:** CORRESPONDENCIA NO VERIFICADA.
   - **Análisis:** No existe trazabilidad de hash ni identificadores unívocos en DataStore para esas cinco variantes; se catalogan formalmente como *CORRESPONDENCIA NO VERIFICADA* para no falsear el inventario.

---

## 4. Auditoría de Dependencias Externas (Estática)

En los archivos HTML de las 12 pantallas se identifican las siguientes llamadas a CDN y servicios de terceros:
- `https://fonts.googleapis.com` y `https://fonts.gstatic.com`: Familias tipográficas `Space Grotesk`, `Space Mono`, `Press Start 2P`, `VT323`.
- `https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined`: Glifos de interfaz táctil.
- `https://cdn.tailwindcss.com`: Compilador JIT en cliente de estilos Tailwind.
- `https://lh3.googleusercontent.com/aida-public/...`: Servidor de blobs de imagen para capturas y fondo `guarderia.png`.

*Recomendación para OpenCode:* Para la integración local offline (127.0.0.1:8787), sustituir los enlaces externos por las tipografías locales y compilar el CSS estáticamente sin CDN.
