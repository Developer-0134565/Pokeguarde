# LEEME_STITCH.md — Pokeguarde para Google Stitch

## 1. Qué es Pokeguarde

Pokeguarde es una **aplicación local** (ejecutada en `127.0.0.1:8787`, sin cuentas ni nube) con dos partes principales:

1. **Biblioteca de saves**: el usuario arrastra un archivo de guardado de Pokémon de Generaciones 1–5 (`.srm`, `.sav`, `.dsv`) y la aplicación muestra un inventario completo de la partida: entrenador, OT/ID, dinero, medallas, tiempo de juego, Pokédex, objetos, cajas y equipo.
2. **Guardería tamagotchi**: el usuario elige un Pokémon y lo lleva a una habitación con estética Game Boy Color (160×144 internos, paleta de 4 colores). La mascota tiene seis necesidades (hambre, felicidad, energía, higiene, disciplina, sueño), realiza acciones (comer, jugar, limpiar, acariciar, reprender, dormir/despertar) y entrena mediante seis minijuegos que **suman EV/stat exp reales** con los topes legales de cada generación. Al terminar, los EV entrenados se exportan a una **copia nueva** del save original, con previsualización (dry-run), informe de diff y validación de legalidad.

**Tecnología**: Backend Bun + TypeScript + SQLite, frontend TypeScript + Canvas (sin frameworks pesados), sidecar C# con PKHeX.Core como única autoridad de parseo y legalidad.

**Usuario**: una sola persona, en escritorio y móvil, que conoce Pokémon y quiere una herramienta precisa pero agradable. **Identidad deseada**: Pokémon GBC / Tamagotchi + interfaz web moderna y cuidada.

---

## 2. Los tres diseños anteriores de Stitch

Estos diseños son **referencias visuales previas** (no implementados):

| Carpeta | Versión | Tamaño | SHA-256 del ZIP original |
|---|---|---|---|
| `guarderia-desktop` | (5) | 1396×1421 | `219b158787d2571e8469fa8582c5ab7d3b8c2473cf59b07a5ff6b42a6b492a2c` |
| `ficha-mobile` | (6) | 302×1600 | `2adf1a5cc15ff41bfd3eae524b21cec6c100ebd4a0604eea9c58985be1e1b88d` |
| `ficha-desktop` | (7) | 1600×1566 | `4ebe38c9917b909b88aaa8d8fed270cf2f660d1b06c5fa3fbd874f5812a98d86` |

Cada carpeta contiene:
- `screen.png` — captura del diseño.
- `DESIGN.md` — descripción del diseño.
- `code.html` — HTML/Tailwind generado (solo referencia visual; **no** se usa como código de producción).
- `original.zip` — paquete original descargado de Stitch (intacto).

**Qué representan:**
- **guarderia-desktop**: carcasa Tamagotchi ovalada roja/blanca con tres botones físicos (izquierdo ciclar, central A/aceptar, derecho B/volver), LCD interior estilo pixel-art GBC/Pokémon Crystal, menú de cuidados (COMER/JUGAR/LIMPIAR/ACARICIAR/REPRENDER/DORMIR-DESPERTAR).
- **ficha-mobile**: ficha estrecha móvil con necesidades, EV/stat exp, entrenamiento, exportación.
- **ficha-desktop**: ficha escritorio expandida con las mismas secciones.

---

## 3. Archivos de referencia visual

Ubicados en `01_REFERENCIAS_ORIGINALES/`:
- `guarderia-desktop/` — diseño de la Guardería con carcasa Tamagotchi.
- `ficha-desktop/` — ficha de Pokémon en escritorio.
- `ficha-mobile/` — ficha de Pokémon en móvil.
- `IMPORTACION_DESDE_CHAT.md` — manifiesto con hashes de los ZIP originales.

Estos archivos son **solo referencias visuales**. Stitch **no debe** copiar el HTML/CSS/Tailwind de `code.html`; son maquetas demostrativas sin lógica real.

---

## 4. Documentación de nuevas funcionalidades

Ubicada en `02_DOCUMENTACION/`:

| Archivo | Estado | Contenido |
|---|---|---|
| `STITCH_DESIGN_BRIEF.md` | Referencia | Brief completo de auditoría visual, prompt maestro, problemas actuales, restricciones. |
| `STITCH_IMPLEMENTATION_PLAN.md` | Referencia | Plan de integración (compatibilidad, orden recomendado, decisiones abiertas). |
| `SHARED_NURSERIES_SPEC.md` | **DECIDED** | Modelo de Guardería (2 plazas), Pestaña Jugadores (11 componentes), Flujo de depósito (7 estados), Cuidado delegado, 3 permisos especiales (bayas EV, minijuegos EV, breeding). |
| `BREEDING_DESIGN_RFC.md` | **PROPOSED** | Reglas de compatibilidad, excepciones (Manaphy/Ditto), cooldown 15 min–3 h (rareza + IV), aceleración con GP, integridad servidor. |
| `MONETIZATION_DESIGN_RFC.md` | **PROPOSED** | Guardipuntos (GP, se ganan jugando, no se compran), 7 sistemas previstos, protección de menores, propiedad intelectual. |
| `POKEMON_SECURITY_RFC.md` | **PROPOSED** | Cifrado en reposo/tránsito, propiedad/autorización, antiduplicación, recuperación. |
| `ROADMAP.md` | **PROPOSED** | Fases 0–10 con etiquetas DECIDED/PROPOSED/UNRESOLVED/DEFERRED. |
| `PG07A_INTEGRATION_REPORT.md` | **DECIDED** | Integración de sprites overworld (fallback procedural, tier por altura Pokédex, tests). |

---

## 5. Decisiones confirmadas vs. pendientes

### ✅ Confirmadas (DECIDED)
- Guardería = **máximo 2 Pokémon** (propios y visitantes).
- **Anfitrión cuida a ambos**; propietario conserva titularidad y derecho de recuperación.
- Modo local **sin cuentas, pagos ni conexión permanente**.
- Flujo de depósito con **7 estados** y reserva atómica de plaza.
- **3 permisos especiales** (bayas EV, minijuegos EV, breeding) desactivados por defecto, revocables, verificados por servidor.
- Sprites overworld: **fallback procedural** + tier por altura Pokédex (GBC16/GBC24/GBC40/GBC64), paleta 4 colores, sin asumir cuadrícula 4×4.
- Canvas lógico **160×144**, nearest-neighbor, HUD en HTML/CSS fuera del lienzo.
- i18n español por defecto, ciclo día/noche (20:00–06:00, fundido 1.2 s preparado).
- Exportación solo a **copia nueva** del save (forma canónica PKHeX), dry-run obligatorio, legalidad no empeora.

### ⚠️ Pendientes (PROPOSED / UNRESOLVED / DEFERRED)
- **Usuarios y autenticación** (para web pública; local sigue sin cuentas).
- **Pestaña Jugadores** (directorio, búsqueda, filtros, amigos, bloqueos, notificaciones).
- **Fórmula de cooldown de huevos** (15 min–3 h según rareza + suma IV — pendiente de definir).
- **Costes de aceleración** (GP/min, topes, redondeo, offline, anti-manipulación de reloj).
- **Reglas de crianza y efectos en partidas originales** (requieren decisiones adicionales).
- **Cifrado, gestión de claves, KMS** (arquitectura propuesta, sin implementar).
- **Modelos comerciales** (cosméticos, Plus, premium, ads, afiliados, donaciones, pases — requieren evaluación legal; no autorizados para lanzamiento).
- **Revisión de derechos de propiedad intelectual** (Pokémon, sprites, elementos protegidos — obligatoria antes de comercializar).

---

## 6. Restricciones obligatorias para Stitch

1. **Estética Tamagotchi**: carcasa **roja y blanca ovalada** con tres botones físicos. LCD interior estilo **pixel-art GBC / Pokémon Crystal** (no estilo carcasa ni web moderna).
2. **Canvas lógico 160×144** conservado. Fondo versionado `guarderia.png` (incluido en `03_RECURSOS_GRAFICOS/`). Pixelación **nearest-neighbor**. Coordenadas y zona caminable ya definidas.
3. **Cuidados**: iconos pixel pequeños + texto simple **COMER / JUGAR / LIMPIAR / ACARICIAR / REPRENDER / DORMIR-DESPERTAR**. **Nada de +%, EV ni cálculos visibles en menús**.
4. **Diálogos y ventanas**: más grandes, temporales, navegación por teclado/táctil y botones del dispositivo.
5. **Navegación objetivo**: GUARDERÍA, FICHA / DATOS, EQUIPO ACTIVO y BIBLIOTECA. **No sustituir** las pestañas actuales de Biblioteca (Equipo/Cajas/Mochila/Legalidad).
6. **Separación de responsabilidades**: Stitch = **diseño visual y flujos**; OpenCode = implementación, validación, persistencia, seguridad y mecánicas. **Las maquetas NO son reglas del juego**.
7. **No introducir React/Tailwind** solo por Stitch. El frontend actual es TypeScript plano servido por Bun (sin Vite).
8. **Cacas**: objeto independiente por encima del fondo, visualmente ≥ 2× la escala del mockup. **No hay aprobación** para frecuencia, penalizaciones, persistencia ni reglas de limpieza nuevas.
9. **Mockups Stitch son demostrativos, NO autoridad de datos**. Sus fichas muestran Gen II junto a 510 EV — **incompatibles** con el stat exp de Gen 1-2 (5 valores hasta 65535, Especial compartido). **Nunca adaptar el motor a esos valores de ejemplo**.
10. **No modificar archivos originales** del repositorio ni incluir secretos/saves/bases de datos.

---

## 7. Uso del paquete

1. Descomprime `POKEGUARDE_STITCH_COMPLETE_2026-11-19.zip`.
2. En Google Stitch, adjunta este paquete junto con el **prompt maestro** incluido en `02_DOCUMENTACION/STITCH_DESIGN_BRIEF.md` (sección "Prompt maestro para Google Stitch").
3. Stitch debe generar **solo diseños** (imágenes, especificaciones visuales, flujos de navegación). **No implementar funcionalidades**.
4. Los diseños se revisarán contra `STITCH_IMPLEMENTATION_PLAN.md` y las restricciones de este `LEEME_STITCH.md` antes de cualquier implementación.

---

## 8. Archivos de recursos gráficos

En `03_RECURSOS_GRAFICOS/`:
- `guarderia.png` — fondo de la habitación (160×144, 10:9, paleta GBC). Es el **fondo versionado** que usa la app en producción. **No sustituir** sin comprobar el fichero exacto.

---

**Fin del paquete.** Preparado para adjuntar directamente a Google Stitch.