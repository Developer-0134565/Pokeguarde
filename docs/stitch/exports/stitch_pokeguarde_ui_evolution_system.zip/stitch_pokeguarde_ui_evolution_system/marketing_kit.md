# POKEGUARDE — MARKETING STUDIO V1 (Admin Suite)
### Arquitectura y Plan de Ejecución para los 13 Módulos de Administración

He analizado a fondo la especificación exhaustiva de **POKEGUARDE — MARKETING STUDIO V1**, así como el dashboard existente (`SCREEN_26`, `SCREEN_24`, `SCREEN_20`, `SCREEN_22`) y la **Default Shell oficial** (`SCREEN_12`, `SCREEN_4`, `SCREEN_2` con el asset protegido `IMAGE_14` de Pokéball Tamagotchi).

---

### 1. Integración en el Dashboard Existente (Sin inventar un diseño competidor)
El **Marketing Studio** se incorpora directamente bajo la jerarquía del dashboard canónico:
- **Barra Superior Canónica**: Hardware `MODEL: PKG-02 SILVER EDITION`, `PWR 100%`, `TRAINER: RED`, saldo `GP [GRATUITO]: 450 GP` y badge distintivo de rol: `ADMINISTRATOR // PRIVILEGED ACCESS [AUTH: 0xADMIN_SYS]`.
- **Sidebar de Navegación Existente**: 
  - Rutas de usuario: `Guardería`, `Ficha / Datos`, `Equipo Activo`, `Jugadores`, `Crianza & Huevos`, `Biblioteca`, `Inventario & Tienda`.
  - **Nueva Sección Privilegiada (ADMIN)**:
    - 🔒 `ADMIN → MARKETING STUDIO` (Hub Principal)
    - Con accesos directos o sub-rutas contextuales a los 13 módulos del Creative Suite.
- **Identidad Pocket Tech 1999**:
  - Paleta: `#fff9ec` / `#faf3e2` (superficies marfil cálidas), `#d93636` / `#b51a21` (rojo Pokeguarde), `#1c1a1a` (bordes técnicos y tipografía charcoal), acentos discretos en cian y dorado.
  - Tipografía: **Space Mono** para telemetría, contadores, slugs y tags de archivo; **Space Grotesk** para controles y textos editoriales.
  - Componentes: Dobles bordes estilo cartucho GBC, chips de estado LED, micro-interruptores y botones físicos con relieve y sombra dura.

---

### 2. Desglose Estructurado de los 13 Módulos Interconectados

1. **Dashboard Principal (`Overview`)**: 4 KPI cards (Total Assets, Campañas Activas, Posts Programados, Rendimiento de Contenido), Quick Actions, Proyectos Recientes, Timeline y Calendario Próximo.
2. **Module 01 — Brand Kit**: Logos (primario, horizontal, icono, fondos claro/oscuro/transparente), paleta oficial con copiado hex, escala tipográfica, y vitrina de la **Default Shell oficial** como activo maestro protegido.
3. **Module 02 — Social Media Studio**: Editor de publicaciones multi-plataforma (X/Twitter, Instagram, TikTok, YouTube, Discord, Reddit) con contador de caracteres, selector de plantillas y previsualización responsive.
4. **Module 03 — Banner & Creative Canvas**: Editor visual tri-panel (Izquierda: Assets/Templates/Shells; Centro: Canvas 16:9, 1:1, 9:16 con guías; Derecha: Inspector de propiedades y capas) con la Shell Default protegida e inmutable.
5. **Module 04 — Press Kit**: Fact sheet, resumen de proyecto, galería de prensa y switch entre *Modo Editor Administrativo* y *Previsualización Pública de Prensa*.
6. **Module 05 — Roadmap & Anuncios**: Tablero Kanban (Planned, In Development, Testing, Released) y editor de comunicados con etiquetas de versión.
7. **Module 06 — Campaign Studio**: Constructor de campañas por fases (Objetivo, Audiencia, Canales, Creatividades, Calendario) y editor de plantillas de Newsletter.
8. **Module 07 — AI Copywriter**: Asistente de redacción contextual con selector de tono (Nostálgico, Amigable, Profesional), tipo de formato y etiquetas obligatorias de contenido generado por IA con recordatorio de revisión humana.
9. **Module 08 — Localización**: Editor paralelo en 2 columnas (ES / EN) con glosario de términos protegidos (sin traducir nombres canónicos de Pokémon).
10. **Module 09 — Media Library**: Gestor DAM (Digital Asset Management) con vistas Grid/Lista, filtros por tipo y metadatos de derechos de autor/fan-project.
11. **Module 10 — Content Calendar**: Calendario editorial mensual con filtros de canales e items categorizados por estado.
12. **Module 11 — Community Hub**: Banco de recursos para Discord (banners de servidor, eventos comunitarios, showcases de la comunidad y directrices de moderación).
13. **Module 12 — Analytics**: Métricas de visitas, clics de campaña, tasa de interacción y embudo de conversión (con indicadores claros de *Datos Ilustrativos de Ejemplo* y estado offline).
14. **Module 13 — Export Center**: Configuración centralizada de exportación (presets Social Pack, Press Kit, Brand Assets; formatos PNG, WebP, SVG, ZIP; control de transparencia y calidad).
15. **Pantalla de Seguridad (Access Denied)**: Estado de acceso denegado para usuarios sin privilegios administrativos con advertencia y botón de retorno al dashboard general.

---

### Siguientes Pasos Recomendados

Para materializar este suite con el máximo nivel de detalle y fidelidad visual:

1. **Opción A (Recomendada)**: Generar primero la **Pantalla Maestra del Hub Principal (Marketing Studio — Overview)**, mostrando las 4 KPI cards, los accesos rápidos a los 13 módulos, el proyecto activo en la Shell oficial y el flujo cruzado de trabajo.
2. **Opción B**: Generar el **Brand Kit & Creative Canvas (Módulos 01 y 03)**, con el estudio visual tri-panel y la vitrina técnica del Default Shell.
3. **Opción C**: Generar el flujo de **Campaña, Redes y Copia (Módulos 02, 06 y 07)**.

¿Prefieres que comience generando la **Pantalla Maestra (Marketing Studio — Overview)** o prefieres priorizar algún módulo específico?