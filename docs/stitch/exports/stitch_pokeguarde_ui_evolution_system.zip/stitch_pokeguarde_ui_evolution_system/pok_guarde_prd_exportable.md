# POKEGUARDE — PROJECT REQUIREMENTS DOCUMENT (PRD) & ARQUITECTURA MAESTRA
**Versión:** 2.4-CANONICAL  
**Fecha:** Noviembre 2026  
**Clasificación:** Documento Técnico de Arquitectura, Diseño & Producto  
**Entorno de Ejecución:** Runtime Local (`127.0.0.1:8787` con Bun) + Interfaz Web Multiplataforma  
**Estándar de Diseño:** Pocket Tech 1999 (Tactile Retro-Digital)  
**ID de Proyecto:** `POKEGUARDE-OS-V2.4`

---

## 1. Visión Ejecutiva del Producto

### 1.1 Resumen Ejecutivo
**Pokéguarde** es una plataforma de preservación, exploración forense y crianza interactiva de partidas de Pokémon de Generaciones I a V (`.sav`, `.srm`, `.dsv`). El proyecto unifica dos necesidades clave:
1. **Un centro forense estricto y desacoplado (Biblioteca de Saves & PG Emulation)**: Garantiza la conservación de partidas originales sin mutación destructiva, inspección de bloques de memoria SRAM mediante sidecar C# en `PKHeX.Core` (.NET 10), y emulación síncrona de cable serie virtual (SCK 8192 Hz) sin alojar ni distribuir ROMs propietarias (cumplimiento DMCA Safe Harbor).
2. **Una guardería interactiva de crianza virtual (Tamagotchi GBC)**: Donde especímenes adoptados residen en una matriz LCD retro-iluminada de 160×144 con seis constantes vitales, minijuegos que entrenan Stat Exp / EVs legales reales, y un sistema de crianza biológica dual con cooldowns e incubación mediante moneda de juego gratuita (Guardipuntos - GP).

### 1.2 Filosofía de Diseño: "Pocket Tech 1999"
- **Tensión estética intencional:** Carcasas de policarbonato moldeado en rojo carmesí y marfil, actuadores de goma con sombras sólidas (`4px 4px 0 #541111`), rejillas acústicas perforadas y biseles de hardware inspirados en la Game Boy Color y la Pokédex de Johto (GSC).
- **Tipografía híbrida:** *Space Mono* para telemetría, contadores, volcados hexadecimales y hashes; *Space Grotesk* para interfaces operativas y lectura legible.

---

## 2. Usuarios Objetivo & Casos de Uso

| Arquetipo | Necesidades Clave | Solución en Pokéguarde |
|---|---|---|
| **Jugador Nostálgico / Coleccionista** | Cuidar a sus Pokémon clásicos como mascotas vivas sin riesgo de pérdida. | Guardería Tamagotchi con persistencia local en SQLite (WAL), necesidades vitales y sprites GBC animados. |
| **Jugador Competitivo / Criador** | Entrenar Stat Exp / EVs legales y eclosionar huevos sin herramientas de trampas invasivas. | Minijuegos de esfuerzo con topes canónicos; Crianza biológica 2 plazas; cálculo verificado por PKHeX. |
| **Investigador / Preservador Forense** | Inspeccionar integridad de memoria, cajas de PC (1-14) y simular enlaces p2p. | Matriz forense PKHeX, Time Capsule Gen I ↔ II, Live Wall de monitoreo serial e intercambio determinista. |
| **Diseñador & Desarrollador (Creator Suite)** | Personalizar carcasas, editar hábitats de pixel-art y gestionar tokens de diseño. | Shell Studio (máscaras WebP/JSON), Habitat Studio (160×144 canvas) y Theme Studio (sincronización con `DESIGN.md`). |

---

## 3. Arquitectura del Sistema (Synapse Data Bus)

El flujo de información se estructura sobre un bus de datos centralizado (*Synapse Data Bus*):

```
┌────────────────────────────────────────────────────────────────────────┐
│                   SYNAPSE DATA BUS // POKÉGUARDE                       │
│  SRAM (.SAV) ↔ PKHeX Core (C#) ↔ Pet Engine (SQLite) ↔ LCD 160×144     │
└───────────────┬────────────────────────────────────────┬───────────────┘
                │                                        │
        [ DOMINIOS DE USUARIO ]                  [ CREATOR SUITE ]
  ┌─────────────────────────────┐        ┌─────────────────────────────┐
  │ 01. NÚCLEO LOCAL & GUARDERÍA│        │ 02. HABITAT STUDIO          │
  │     - Guardería (2 plazas)  │        │     - Editor de Baldosas    │
  │     - Ficha / Datos         │        │     - Presets Ambientales   │
  │     - Biblioteca & Cajas    │        │     - Chassis Simulator     │
  │     - Crianza & Eclosión    │        ├─────────────────────────────┤
  │     - Tienda GP & Decoración│        │ 03. SHELL STUDIO            │
  ├─────────────────────────────┤        │     - Editor Tri-Panel      │
  │ 05. FORENSICS & LEGALIDAD   │        │     - Multi-Ángulo 3D/WebP  │
  │     - Inspector PKHeX       │        │     - Export Center JSON    │
  ├─────────────────────────────┤        ├─────────────────────────────┤
  │ 06. PG EMULATION & CLUSTER  │        │ 04. THEME STUDIO            │
  │     - Live Wall (6 Feeds)   │        │     - 8 Módulos de Tokens   │
  │     - Cable Link 8192 Hz    │        │     - Pipeline DESIGN.md    │
  └─────────────────────────────┘        └─────────────────────────────┘
```

---

## 4. Requisitos Funcionales por Dominio

### 4.1 Dominio 01: Núcleo Local, Jugador & Guardería
- **RF-01.1 Guardería Bi-Plaza (2/2 Pokémon):** Alojamiento de hasta 2 especímenes simultáneos (propios o visitantes). El anfitrión cuida de ambos sin alterar la propiedad original del visitante.
- **RF-01.2 Las 6 Constantes Vitales:**
  - *Comida (Saciedad)*, *Felicidad (Afecto)*, *Energía Vital*, *Higiene & Salud*, *Disciplina Táctica*, *Sueño & Reposo*.
  - 6 acciones físicas estándar: `COMER`, `JUGAR`, `LIMPIAR`, `ACARICIAR`, `REPRENDER`, `DORMIR/DESPERTAR`.
- **RF-01.3 Lienzo Lógico 160×144:** Proporción canónica Game Boy Color (10:9) renderizada con filtrado *nearest-neighbor* sin antialiasing, integrado en carcasa física ovalada con actuadores táctiles.
- **RF-01.4 Crianza Biológica & Eclosión:**
  - Validación de compatibilidad biológica con soporte para excepciones canónicas (Manaphy + Ditto → Phione).
  - Entrega simétrica de dos huevos (1 para cada entrenador) con cooldown de incubación (15 min – 3 h) reducible mediante Guardipuntos (GP gratuitos).
  - Secuencia de eclosión animada en 4 etapas: *Vibración → Grietas → Destello lumínico → Aparición de la cría*.
- **RF-01.5 Economía Ética (Guardipuntos - GP):** Moneda virtual gratuita que se obtiene exclusivamente cuidando mascotas y superando minijuegos. Cero compras con dinero real, cero microtransacciones, protección estricta de menores.

### 4.2 Dominio 02: Biblioteca & Inspección Forense PKHeX
- **RF-02.1 Ingesta de Partidas:** Carga arrastrando archivos `.sav`, `.srm`, `.dsv` (32 KB – 512 KB) de Generaciones 1 a 5.
- **RF-02.2 Integridad y Escritura Segura:** La aplicación nunca sobreescribe el archivo `.sav` original; exporta siempre a un clon nuevo tras un proceso de *dry-run* y verificación criptográfica CRC16/SHA-256.
- **RF-02.3 Explorador de Cajas de PC (1-14):** Visualización en cuadrícula con banderas de legalidad explícitas (`Legal`, `No verificable`, `Ilegal`).
- **RF-02.4 Protocolo Time Capsule (Gen I ↔ Gen II):** Conversión de estructuras de datos y detección de ataques o atributos anacrónicos.

### 4.3 Dominio 03: PG Emulation & Cluster Serial
- **RF-03.1 Protocolo Zero-ROM:** Emulación de hardware neutra y desacoplada mediante WebAssembly y WebSockets locales (`127.0.0.1:8787`). No se distribuyen ni ejecutan binarios comerciales con derechos de autor.
- **RF-03.2 Live Wall Multivisor:** Visualización simultánea de canales de enlace serial a 8192 Hz:
  - *Canal 01:* Johto Silver Cup (1v1 Combate).
  - *Canal 02:* Time Capsule Bridge (GSC ↔ RBY).
  - *Canal 03:* Guardería Co-op Live (Ruta 34 Síncrona).
  - *Canal 04:* Torneo Copa Plata (Arbitraje estricto).
- **RF-03.3 Control de Conexión & Resiliencia:** Recuperación ante pérdida de portadora (*timeout* 15s), volcado hexadecimal de búfer de 33 bytes, y botón de *Rollback Atómico* para garantizar indemnidad de la SRAM.

### 4.4 Dominio 04: Creator Suite (Shell, Habitat & Theme Studio)
- **RF-04.1 Shell Studio:** Editor de carcasas físicas con ajuste de biseles, texturas plásticas (Atomic Purple, Solid Crimson, Gold Cartridge), render 3D multi-ángulo y exportador de máscaras WebP sin pérdidas + manifiesto JSON.
- **RF-04.2 Habitat Studio:** Diseñador de dormitorios y biomas en baldosa pixel-art (160×144) con simulación de ciclo día/noche y comprobación de legibilidad STN.
- **RF-04.3 Theme Studio:** Gobernanza de diseño atómico a través de 8 módulos coordinados (Colores, Tipografía, Espaciado, Componentes, Layout, Matrix Preview, Token Manager y sincronización bidireccional con `DESIGN.md`).

### 4.5 Dominio 05: Marketing Studio (13 Módulos de Difusión)
- **RF-05.1 Suite Completa de Difusión:** Módulos de Brand Kit, Social Studio, Canvas de Banners (16:9, 1:1, 9:16), Dossier de Prensa, Roadmap Kanban, Generador de Campañas, Asistente de Redacción Contextual, Localización Bilingüe (ES/EN con glosario canónico protegido), DAM de Recursos, Calendario de Contenidos, Hub de Discord, Motor de Analíticas y Centro de Empaquetado.

---

## 5. Requisitos No Funcionales (RNF)

| Dimensión | Requisito Técnico | Criterio de Aceptación |
|---|---|---|
| **Rendimiento** | FPS de renderizado de la matriz LCD | 59.97 FPS constantes; latencia de bus de enlace < 1.5 ms. |
| **Privacidad & Red** | Ejecución local y air-gapped | 100% operativo en localhost (`127.0.0.1`); sin telemetría externa obligatoria ni rastreo de menores. |
| **Integridad de Datos** | Tolerancia a fallos de SRAM | Garantía de Cero Pérdidas; transacciones de guardado atómicas con reversión automática en desconexión. |
| **Accesibilidad (a11y)** | Cumplimiento WCAG 2.1 AA | Contraste de texto ≥ 4.5:1 (8.2:1 en superficies marfil/carbón); estados codificados con texto + icono (nunca solo color); soporte para `prefers-reduced-motion`. |
| **Resolución & Escala** | Escalamiento de matriz de píxeles | Escala entera nítida (2× a 7×) con `image-rendering: pixelated`; sin desenfoque bilineal en la pantalla LCD. |

---

## 6. Pila Tecnológica & Arquitectura de Software

- **Backend Runtime:** [Bun](https://bun.sh) (TypeScript nativo de alto rendimiento).
- **Almacenamiento Local:** SQLite con modo WAL (*Write-Ahead Logging*) para persistencia de estados de mascotas, habitaciones y logs de enlace.
- **Sidecar de Validación Forense:** C# con `PKHeX.Core` corriendo como proceso local aislado vía pipes IPC estándar.
- **Frontend:** TypeScript puro + HTML5 Canvas (sin frameworks pesados innecesarios) servido por Bun.
- **Estilos:** Tailwind CSS con tokens semánticos definidos en el estándar `Pocket Tech 1999` (`DESIGN.md`).
- **Sincronización:** WebSockets locales (`ws://127.0.0.1:8787`) para telemetría síncrona a 60 Hz.

---

## 7. Matriz de Estados de Resiliencia & Seguridad

```
ESTADO FSM         EVENTO DISPARADOR        ACCIÓN DEL SISTEMA             CRITERIO DE RESILIENCIA
─────────────────────────────────────────────────────────────────────────────────────────────────
0x01_CARGANDO      Handshake serial         Bloqueo preventivo de inputs   Timeout 5000ms con reintento
0x02_VACÍO         Sin datos / Sala libre   Render de placeholder neutral  Sondeo pasivo a 2000ms
0x03_ÉXITO         ACK canónico 0x60/0x61   Canal síncrono habilitado      Partida continua CRC16 OK
0x04_ERROR         Checksum mismatch        Alerta modal roja              Preservación de .SAV intacto
0x05_DESCONEXIÓN   Pérdida de señal SCK     Auto-rollback de búferes       Cero corrupción de memoria
```

---
*Pokéguarde — Sistema Autónomo de Preservación y Crianza. Cumplimiento DMCA Safe Harbor & Cero Dependencia de ROMs Propietarias.*
