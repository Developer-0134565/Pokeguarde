# POKEGUARDE — RESUMEN FINAL Y CHECKLIST DE IMPLEMENTACIÓN
**Documento de Entrega de Diseño · Google Stitch → Equipo de Desarrollo (OpenCode / Bun / TypeScript / .NET)**  
**Fecha de Cierre:** 2026-11-20  
**Sistema de Diseño:** *Pocket Tech 1999* (`Space Mono` + `Space Grotesk`, paleta física Game Boy Color / Molded Resin GBC)  
**Autoridad de Legalidad y Reglas:** `PKHeX.Core (.NET 10)`  

---

## 1. Resumen Ejecutivo del Proyecto

Pokeguarde ha evolucionado desde una herramienta local de inspección de saves hacia una plataforma de coleccionismo y crianza híbrida:
1. **Modo Local Offline Perpetuo (127.0.0.1:8787):** Sin registro ni nube obligatoria. Arrastrar save (`.sav`, `.srm`, `.dsv`), explorar inventario completo (Cajas 1-14, Equipo, Mochila) y auditar legalidad forense.
2. **Guardería Tamagotchi Retromoderna (Capacidad 2 Pokémon):** Canvas lógico 160×144 píxeles en escala entera nearest-neighbor sobre el fondo canónico `guarderia.png`. Carcasa ovalada física con 3 actuadores (Navegar / Aceptar / Cancelar), 6 necesidades básicas y 6 minijuegos con cálculo de Stat Exp real (tope 65,535 en Gen I/II).
3. **Cuidado Delegado & Guarderías Compartidas (PG-08):** Conexión opcional entre entrenadores con permisos independientes (Bayas EV, Minijuegos EV, Breeding), garantizando la propiedad inalienable del dueño original y recuperación ante desconexión.
4. **Crianza Canónica & Incubación GP (PG-09 / PG-10):** Reglas biológicas verídicas, compatibilidad con excepciones (Manaphy/Ditto), entrega de 1 huevo aleatorio a cada participante, aceleración exclusiva mediante Guardipuntos (GP ganados jugando, 0 pay-to-win) y secuencia de eclosión en 4 etapas.

---

## 2. Inventario de Pantallas Diseñadas en Stitch

| ID Pantalla | Título en Canvas | Formato | Rol & Contenido Clave |
| :--- | :--- | :--- | :--- |
| **SCREEN_25** | `Guardería (2/2 Pokémon) — Escritorio` | Desktop | Carcasa Tamagotchi roja ovalada, 2 mascotas activas simultáneas, HUD HTML exterior, 3 botones físicos y menú cuidados GBC. |
| **SCREEN_23** | `Ficha / Datos — Manaphy Visitante & Permisos` | Desktop | Ficha técnica, procedencia, 6 necesidades, matriz de EVs/Stat Exp y conmutadores de los 3 permisos especiales delegados. |
| **SCREEN_21** | `Directorio de Jugadores & Guarderías Compartidas` | Desktop | Directorio de anfitriones, filtros de admisión/visibilidad, estado de las 2 plazas, solicitudes y políticas de seguridad. |
| **SCREEN_19** | `Crianza & Huevos — Selección de Pareja & Validación` | Desktop | Compatibilidad biológica, grupos huevo, paridad Manaphy/Ditto, mitigación de esterilidad y cálculo de cooldown (15 min - 3 h). |
| **SCREEN_17** | `Crianza & Huevos — Entrega de 2 Huevos & Incubación GP` | Desktop | Reparto de 1 huevo por entrenador, barra de incubación, aceleración con saldo de GP y advertencia anti-manipulación RTC. |
| **SCREEN_15** | `Crianza & Huevos — Secuencia de Eclosión Phione` | Desktop | Storyboard secuencial de 4 fotogramas en LCD GBC 160×144 (Vibración → Grietas → Destello → Cría recién nacida). |
| **SCREEN_13** | `Crianza & Huevos — Animación Interactiva Phione` | Desktop | Versión interactiva con selector de fase, animación de partículas CSS/Canvas y opciones de destino post-eclosión. |
| **SCREEN_10** | `Tienda de Guardipuntos (GP) & Editor de Decoración` | Desktop | Catálogo de muebles/tapetes/consolas retro para la guardería, saldo de GP obtenido jugando y política estricta de protección de menores. |
| **SCREEN_8** | `Perfil de Jugador, Notificaciones & Privacidad` | Desktop | Datos del entrenador, registro de transacciones GP, lista local de bloqueos y configuración de visibilidad de guardería. |
| **SCREEN_6** | `Biblioteca — Equipo Activo & Mochila` | Desktop | Vista de los 6 miembros del equipo, bolsillos de mochila por categorías y traspaso directo hacia la Guardería. |
| **SCREEN_4** | `Biblioteca — Cajas de PC (1-14) & Filtros Legalidad` | Desktop | 14 bancos SRAM, matriz de 20 slots, buscador dinámico y filtros de auditoría (Legales, No Verificables, Ilegales). |
| **SCREEN_2** | `Inspección Forense — Detalle Legalidad Celebi GS-Ball` | Desktop | Diagnóstico forense a bajo nivel: DVs 0-15, volcado hex SRAM, log PKHeX.Core, movimientos no conformes y protocolos de aislamiento. |

---

## 3. Checklist Técnico para el Equipo de Desarrollo

### A. Canvas & Renderizado de la Guardería (Fase 6 / PG-07A)
- [ ] **Resolución Nativa Inviolable:** Mantener estrictamente el canvas lógico interno en **160×144 píxeles (10:9)**.
- [ ] **Escalado Nearest-Neighbor:** Aplicar `imageSmoothingEnabled = false` y `image-rendering: pixelated` con escala CSS entera (2× a 7× según viewport).
- [ ] **Fondo Canónico:** Utilizar exclusivamente `guarderia.png` sin estirar ni deformar la perspectiva.
- [ ] **HUD Externo HTML:** El barómetro de las 6 necesidades y reloj debe renderizarse en el DOM HTML exterior, alineado al ancho exacto del canvas (`160 * escala`).
- [ ] **Sprites Overworld PG-07A:** Reutilizar `sprite-runtime.ts` con tier de altura Pokédex (16/24/40/64) y fallback procedural automático si el PNG no está en caché o está en pose de sueño.
- [ ] **Carcasa & Botonera:** Carcasa ovalada rojo/blanco renderizada en CSS puro con 3 controles físicos:
  - Botón Izquierdo: Ciclar selección (`ArrowDown`, `ArrowRight`, `A`).
  - Botón Central: Confirmar / Aceptar (`Enter`, `Space`).
  - Botón Derecho: Cancelar / Menú (`Escape`, `B`).

### B. Modelo de Datos & Guarderías Compartidas (Fase 7 / PG-08)
- [ ] **Capacidad Atómica:** La guardería admite **máximo 2 Pokémon simultáneos** (propios o en estancia compartida).
- [ ] **Máquina de Estados de Depósito (7 Estados):** Implementar transiciones atómicas:
  `1. Disponible` → `2. Solicitud pendiente` → `3. Aceptada/Rechazada` → `4. Estancia activa` → `5. Recogida solicitada` → `6. Estancia finalizada` / `7. Error recuperable`.
- [ ] **Propiedad & Rescate Autónomo:** El Pokémon nunca pierde su propietario original (`user_id`). El dueño puede recuperar a su criatura incluso si el anfitrión está offline o la conexión se interrumpe.
- [ ] **Permisos Especiales (3 Flags Booleanas):**
  - `allow_ev_berries`: Desactivado por defecto.
  - `allow_ev_minigames`: Desactivado por defecto.
  - `allow_breeding`: Desactivado por defecto.
  - *Verificación obligatoria en backend antes de ejecutar cualquier mutación de EV o solicitud de cópula.*

### C. Motor Biológico de Crianza & Huevos (Fase 8 / PG-09)
- [ ] **Validación Canónica de Grupos Huevo:** Verificar coincidencia de grupos y género compatible.
- [ ] **Excepciones Legendarias:** Soportar regla especial Manaphy + Ditto = Huevo de Phione (#489). Bloquear crianza de bebés y legendarios no permitidos.
- [ ] **Generación Justa (1 Huevo c/u):** Si participan 2 entrenadores distintos, el sistema emite **1 huevo para el anfitrión y 1 huevo para el visitante**.
- [ ] **Cooldown de Incubación:** Intervalo base de 15 minutos a 3 horas según rareza y suma de IVs.
- [ ] **Aceleración con GP:** Permitir consumo de Guardipuntos (GP) para descontar tiempo de eclosión, con verificación horaria en servidor contra timestamps UTC para evitar trampas de manipulación de reloj del cliente.

### D. Economía de Guardipuntos & Tienda (Fase 9 / PG-10)
- [ ] **GP 100% Gratuitos:** Los GP se generan únicamente completando minijuegos, cuidando mascotas y alcanzando hitos.
- [ ] **Cero Microtransacciones:** No integrar pasarelas de pago, suscripciones con dinero real ni loot boxes (cumplimiento estricto de protección de menores).
- [ ] **Decoración de Guardería:** Los objetos cosméticos comprados se almacenan en SQLite local y conmutan capas sobre la habitación.

### E. Integridad de Partida & Auditoría PKHeX (Fase 1 / 2)
- [ ] **Exportación Segura (Dry-Run Obligatorio):** Ninguna escritura sobreescribe el `.sav` original. Se exporta siempre a un archivo nuevo con previsualización de diferencias.
- [ ] **Rigor de Generación II:** En saves de Gen 1 y 2, los DVs son 0-15 y el Stat Exp suma hasta 65,535 (5 valores, Especial compartido). Prohibido inyectar 510 EV o naturalezas modernas en estructuras Gen I/II.
- [ ] **Cuarentena de Anomalías:** Pokémon que violen legalidad PKHeX (ej. movimientos ilegales, nivel de encuentro anómalo) quedan bloqueados para su ingreso a la Guardería o intercambio multijugador.

---

## 4. Estado de Decisiones para OpenCode

- **DECIDED (Listo para picar código):** Guardería 2 plazas, 3 permisos revocables, flujo de 7 estados de depósito, canvas 160×144 nearest-neighbor, reparto de 1 huevo por jugador, GP gratuitos sin compras in-app.
- **PROPOSED / PENDIENTE:** Fórmula polinomial exacta del tiempo de cooldown por especie/IV, algoritmo exacto de herencia genética de movimientos en servidor y autenticación para despliegue en web pública (el modo local sigue 100% sin cuentas).

---
*Fin del informe de entrega. Diseños y especificaciones disponibles en el workspace de Google Stitch.*