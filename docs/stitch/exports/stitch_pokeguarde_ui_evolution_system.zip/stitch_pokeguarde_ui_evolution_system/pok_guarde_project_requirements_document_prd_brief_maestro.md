# POKEGUARDE — PROJECT REQUIREMENTS DOCUMENT (PRD) & ARQUITECTURA MAESTRA
**Versión:** 2.4-CANONICAL  
**Fecha:** Noviembre 2026  
**Clasificación:** Ingeniería, Diseño & Producto  
**Entorno de Ejecución:** Runtime Local (`127.0.0.1:8787` servido con Bun) + Interfaz Web Multiplataforma  
**Sistema de Diseño:** Pocket Tech 1999 (Tactile Retro-Digital)

---

## 1. Visión Ejecutiva del Producto

### 1.1 Resumen Ejecutivo
**Pokéguarde** es un ecosistema local y web para la preservación, exploración forense y crianza interactiva de partidas de Pokémon de Generaciones I a V (`.sav`, `.srm`, `.dsv`). El proyecto fusiona dos mundos:
1. **Un centro forense estricto y desacoplado (Biblioteca de Saves & PG Emulation)** que garantiza preservación sin corrupción, lectura de bloques SRAM mediante PKHeX.Core (.NET 10) en C#, y emulación de enlace por cable serie virtual (SCK 8192 Hz) sin ROMs propietarias (DMCA Safe Harbor).
2. **Una guardería interactiva de crianza virtual (Tamagotchi GBC)** donde especímenes adoptados residen dentro de una matriz LCD retro-iluminada 160×144 con seis constantes vitales, minijuegos que entrenan EVs/Stat Exp reales canónicos, y un sistema de crianza cooperativa bi-plaza con eclosión procedural.

### 1.2 Filosofía de Diseño: "Pocket Tech 1999"
- **Tensión estética intencional:** Cajas de hardware moldeadas en policarbonato rojo/marfil, actuadores de goma mate con sombras sólidas (`4px 4px 0 #541111`), rejillas acústicas perforadas y marcos biselados inspirados en la Game Boy Color y la Pokédex de Johto (GSC).
- **Tipografía híbrida:** Monospace estricto (*Space Mono*) para registros de telemetría, contadores, registros de paquetes y volcado hexadecimal; sans-serif geométrico (*Space Grotesk*) para interfaces operativas y lectura legible.

---

## 2. Usuarios Objetivo & Casos de Uso

| Arquetipo | Necesidades Clave | Solución en Pokéguarde |
|---|---|---|
| **Jugador Nostálgico / Coleccionista** | Cuidar a sus Pokémon clásicos como mascotas vivas sin riesgo de pérdida. | Guardería Tamagotchi con persistencia local en SQLite (WAL), necesidades vitales y sprites GBC animados. |
| **Jugador Competitivo / Criador** | Entrenar Stat Exp / EVs legales y eclosionar huevos sin herramientas de trampas invasivas. | Minijuegos de esfuerzo con topes canónicos; Crianza biológica 2 plazas; cálculo verificado por PKHeX. |
| **Investigador / Preservador Forense** | Inspeccionar integridad de memoria, cajas de PC (1-14) y simular enlaces p2p. | Matriz forense PKHeX, Time Capsule Gen I ↔ II, Live Wall de monitoreo serial e intercambio determinista. |
| **Diseñador & Desarrollador (Creator Suite)** | Personalizar carcasas, editar hábitats de pixel-art y gestionar tokens de diseño. | Shell Studio (máscaras WebP/JSON), Habitat Studio (160×144 canvas) y Theme Studio (sincronización con `DESIGN.md`). |

---

## 3. Arquitectura del Sistema & Dominios Funcionales

El proyecto se divide en **6 Dominios Nucleares Interconectados**, respaldados por un canal de bus común (*Synapse Data Bus*):

```
┌────────────────────────────────────────────────────────────────────────┐
│                   SYNAPSE DATA BUS // POKÉGUARDE                       │
│  SRAM (.SAV) ↔ PKHeX Core (C#) ↔ Pet Engine (SQLite) ↔ LCD 160×144     │
└───────────────┬────────────────────────────────────────┬───────────────┘
                │                                        │
        [ DOMINIOS DE USUARIO ]                  [ CREATOR SUITE ]
  ┌─────────────────────────────┐        ┌─────────────────────────────┐
  │ 01. NÚCLEO LOCAL & GUARDERÍA│        │ 02. HABITAT STUDIO          │
  │     - Guardería (2 plazas)  │        │     - Editor de Baldosas    │
  │     - Ficha / Datos         │        │     - Presets Ambientales   │
  │     - Biblioteca & Cajas    │        │     - Chassis Simulator     │
  │     - Crianza & Eclosión    │        ├─────────────────────────────┤
  │     - Tienda GP & Decoración│        │ 03. SHELL STUDIO            │
  ├─────────────────────────────┤        │     - Editor Tri-Panel      │
  │ 05. FORENSICS & LEGALIDAD   │        │     - Multi-Ángulo 3D/WebP  │
  │     - Inspector PKHeX       │        │     - Export Center JSON    │
  │     - Time Capsule Gen I/II │        ├─────────────────────────────┤
  │     - Cajas PC (Filtros)    │        │ 04. THEME STUDIO            │
  ├─────────────────────────────┤        │     - 8 Módulos de Tokens   │
  │ 06. PG EMULATION & CLUSTER  │        │     - Live Preview Matrix   │
  │     - Live Wall (6 Feeds)   │        │     - Pipeline DESIGN.md    │
  ├─────────────────────────────┤        ├─────────────────────────────┤
  │                             │        │ 05. MARKETING STUDIO (13 M) │
  │                             │        │     - Brand Kit & DAM       │
  │                             │        │     - Campaign & Analytics  │
  └─────────────────────────────┘        └─────────────────────────────┘
```

---

## 4. Requisitos Funcionales por Dominio

### 4.1 Dominio 01: Núcleo Local, Jugador & Guardería
- **RF-01.1 Guardería Bi-Plaza (2/2 Pokémon):** Alojamiento de hasta 2 especímenes simultáneos (propios o de visitantes). El anfitrión cuida a ambos sin transferir la titularidad del visitante.
- **RF-01.2 Las 6 Constantes Vitales:**
  - *Comida (Saciedad)*, *Felicidad (Afecto)*, *Energía Vital*, *Higiene & Salud*, *Disciplina Táctica*, *Sueño & Reposo*.
  - Menú de 6 acciones físicas: `COMER`, `JUGAR`, `LIMPIAR`, `ACARICIAR`, `REPRENDER`, `DORMIR/DESPERTAR`.
- **RF-01.3 Lienzo Lógico 160×144:** Proporción canónica Game Boy Color (10:9) renderizada con filtrado *nearest-neighbor* sin antialiasing, integrado en la carcasa ovalada con 3 actuadores físicos (`IZQ: Navegar`, `CENTRO: Confirmar`, `DER: Cancelar`).
- **RF-01.4 Crianza Biológica & Eclosión:**
  - Validación de compatibilidad biológica con soporte para excepciones de evento (Manaphy + Ditto → Huevo Phione).
  - Entrega simétrica de dos huevos (1 para cada entrenador) con cooldown de incubación (15 min – 3 h) reducible mediante Guardipuntos (GP gratuitos).
  - Secuencia de eclosión animada en 4 etapas: *Vibración → Grietas superficiales → Destello lumínico → Aparición de la cría*.
- **RF-01.5 Economía Ética (Guardipuntos - GP):** Moneda virtual gratuita que se obtiene exclusivamente jugando minijuegos y cuidando mascotas. **Cero compras con dinero real, cero loot-boxes, protección infantil absoluta.**

### 4.2 Dominio 02: Biblioteca & Inspección Forense PKHeX
- **RF-02.1 Ingesta de Partidas:** Carga arrastrando archivos `.sav`, `.srm`, `.dsv` (32 KB – 512 KB) de Generaciones 1 a 5.
- **RF-02.2 Integridad y Escritura Segura:** La aplicación nunca sobreescribe el archivo `.sav` original; exporta siempre a un clon nuevo tras un proceso de *dry-run* y verificación criptográfica CRC16/SHA-256.
- **RF-02.3 Explorador de Cajas de PC (1-14):** Visualización en cuadrícula con banderas de legalidad explícitas (`Legal`, `No verificable`, `Ilegal`).
- **RF-02.4 Protocolo Time Capsule (Gen I ↔ Gen II):** Conversión de estructuras de datos y detección de ataques o atributos anacrónicos (bloqueo de movimientos Gen II en transferencias a RBY).

### 4.3 Dominio 03: PG Emulation & Cluster Serial
- **RF-03.1 Protocolo Zero-ROM:** Emulación de hardware neutra y desacoplada mediante WebAssembly y WebSockets locales (`127.0.0.1:8787`). No se distribuyen ni ejecutan binarios comerciales con derechos de autor.
- **RF-03.2 Live Wall Multivisor:** Visualización simultánea de canales de enlace serial a 8192 Hz:
  - *Canal 01:* Johto Silver Cup (1v1 Combate).
  - *Canal 02:* Time Capsule Bridge (GSC ↔ RBY).
  - *Canal 03:* Guardería Co-op Live (Ruta 34 Síncrona).
  - *Canal 04:* Torneo Copa Plata (Arbitraje estricto).
- **RF-03.3 Control de Conexión & Resiliencia:** Recuperación ante pérdida de portadora (*timeout* 15s), volcado hexadecimal de búfer de 33 bytes, y botón de *Rollback Atómico* para garantizar indemnidad de la SRAM.

### 4.4 Dominio 04: Creator Suite (Shell, Habitat & Theme Studio)
- **RF-04.1 Shell Studio:** Editor de carcasas físicas con ajuste de biseles, texturas plásticas (Atomic Purple, Solid Crimson, Gold Cartridge), render 3D multi-ángulo y exportador de máscaras WebP sin pérdidas + manifiesto JSON.
- **RF-04.2 Habitat Studio:** Diseñador de dormitorios y biomas en baldosa pixel-art (160×144) con simulación de ciclo día/noche y comprobación de legibilidad STN.
- **RF-04.3 Theme Studio:** Gobernanza de diseño atómico a través de 8 módulos coordinados (Colores, Tipografía, Espaciado, Componentes, Layout, Matrix Preview, Token Manager y sincronización bidireccional con `DESIGN.md`).

### 4.5 Dominio 05: Marketing Studio (13 Módulos de Difusión)
- **RF-05.1 Suite Completa de Difusión:** Módulos de Brand Kit, Social Studio, Canvas de Banners (16:9, 1:1, 9:16), Dossier de Prensa, Roadmap Kanban, Generador de Campañas, Asistente de Redacción Contextual, Localización Bilingüe (ES/EN con glosario canónico protegido), DAM de Recursos, Calendario de Contenidos, Hub de Discord, Motor de Analíticas y Centro de Empaquetado.

---

## 5. Requisitos No Funcionales (RNF)

| Dimensión | Requisito Técnico | Criterio de Aceptación |
|---|---|---|
| **Rendimiento** | FPS de renderizado de la matriz LCD | 59.97 FPS constantes; latencia de bus de enlace < 1.5 ms. |
| **Privacidad & Red** | Ejecución local y air-gapped | 100% operativo en localhost (`127.0.0.1`); sin telemetría externa obligatoria ni rastreo de menores. |
| **Integridad de Datos** | Tolerancia a fallos de SRAM | Garantía de Cero Pérdidas; transacciones de guardado atómicas con reversión automática en desconexión. |
| **Accesibilidad (a11y)** | Cumplimiento WCAG 2.1 AA | Contraste de texto ≥ 4.5:1 (8.2:1 en superficies marfil/carbón); estados codificados con texto + icono (nunca solo color); soporte para `prefers-reduced-motion`. |
| **Resolución & Escala** | Escalamiento de matriz de píxeles | Escala entera nítida (2× a 7×) con `image-rendering: pixelated`; sin desenfoque bilineal en la pantalla LCD. |

---

## 6. Pila Tecnológica & Arquitectura de Software

- **Backend Runtime:** [Bun](https://bun.sh) (TypeScript nativo de alto rendimiento).
- **Almacenamiento Local:** SQLite con modo WAL (*Write-Ahead Logging*) para persistencia de estados de mascotas, habitaciones y logs de enlace.
- **Sidecar de Validación Forense:** C# con `PKHeX.Core` corriendo como proceso local aislado vía pipes IPC estándar.
- **Frontend:** TypeScript puro + HTML5 Canvas (sin frameworks sobrecargados) servido directamente por el router de Bun.
- **Estilos:** Tailwind CSS con tokens semánticos definidos en el estándar `Pocket Tech 1999` (`DESIGN.md`).
- **Sincronización:** WebSockets locales (`ws://127.0.0.1:8787`) para telemetría síncrona a 60 Hz.

---

## 7. Matriz de Estados de Resiliencia & Seguridad

```
ESTADO FSM         EVENTO DISPARADOR        ACCIÓN DEL SISTEMA             CRITERIO DE RESILIENCIA
─────────────────────────────────────────────────────────────────────────────────────────────────
0x01_CARGANDO      Handshake serial         Bloqueo preventivo de inputs   Timeout 5000ms con reintento
0x02_VACÍO         Sin datos / Sala libre   Render de placeholder neutral  Sondeo pasivo a 2000ms
0x03_ÉXITO         ACK canónico 0x60/0x61   Canal síncrono habilitado      Partida continua CRC16 OK
0x04_ERROR         Checksum mismatch        Alerta modal roja              Preservación de .SAV intacto
0x05_DESCONEXIÓN   Pérdida de señal SCK     Auto-rollback de búferes       Cero corrupción de memoria
```

---

## 8. Hitos del Proyecto & Estado de Entrega

- [x] **Fase 0:** Auditoría de código, validación de paridad PKHeX y spike de rendimiento.
- [x] **Fase 1:** Ingesta de partidas, inventario de mochilas y cajas PC 1-14.
- [x] **Fase 2:** Integración del Tamagotchi de Guardería 160×144 con controles A/B/C.
- [x] **Fase 3:** Soporte dual (Guardería 2 Pokémon con visitantes y delegación de cuidados).
- [x] **Fase 4:** Crianza biológica, animación de eclosión Phione y economía ética de Guardipuntos (GP).
- [x] **Fase 5:** Suite de personalización (Shell Studio, Habitat Studio, Theme Studio).
- [x] **Fase 6:** Suite de difusión (Marketing Studio con 13 módulos completos).
- [x] **Fase 7:** PG Emulation Suite (Live Wall, adaptadores desacoplados y bus serial virtual).
- [x] **Fase 8:** Mapa de Navegación General y Taxonomía Unificada de 52+ Pantallas.

---
*Pokéguarde — Sistema Autónomo de Preservación y Crianza. Cumplimiento DMCA Safe Harbor & Cero Dependencia de ROMs Propietarias.*
