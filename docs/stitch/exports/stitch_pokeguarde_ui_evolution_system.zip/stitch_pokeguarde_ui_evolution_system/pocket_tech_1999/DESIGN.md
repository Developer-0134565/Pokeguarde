---
name: Pocket Tech 1999
colors:
  surface: '#fff9ec'
  surface-dim: '#e0dac9'
  surface-bright: '#fff9ec'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf3e2'
  surface-container: '#f4eddd'
  surface-container-high: '#eee8d7'
  surface-container-highest: '#e8e2d2'
  on-surface: '#1e1c12'
  on-surface-variant: '#5b403e'
  inverse-surface: '#333025'
  inverse-on-surface: '#f7f0e0'
  outline: '#8f706d'
  outline-variant: '#e3beba'
  surface-tint: '#b91d23'
  primary: '#b51a21'
  on-primary: '#ffffff'
  primary-container: '#d93636'
  on-primary-container: '#fffcff'
  inverse-primary: '#ffb3ad'
  secondary: '#0055c7'
  on-secondary: '#ffffff'
  secondary-container: '#146df4'
  on-secondary-container: '#fefcff'
  tertiary: '#765700'
  on-tertiary: '#ffffff'
  tertiary-container: '#956e00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ad'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#930011'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#b0c6ff'
  on-secondary-fixed: '#001945'
  on-secondary-fixed-variant: '#00419c'
  tertiary-fixed: '#ffdfa0'
  tertiary-fixed-dim: '#f8bd2a'
  on-tertiary-fixed: '#261a00'
  on-tertiary-fixed-variant: '#5c4300'
  background: '#fff9ec'
  on-background: '#1e1c12'
  surface-variant: '#e8e2d2'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Space Mono
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Space Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-md:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Space Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
This design system channels the nostalgic tactile realism of late-90s handheld gaming hardware (Generation II Pokémon cartridges, Game Boy Color, and virtual pets) merged with modern interactive software architecture. The aesthetic embraces industrial plastic molding, physical bevels, deep LCD bezels, and mechanical micro-switches rather than flat digital minimalism.

The brand persona is nostalgic, engineered, durable, and playful. Surfaces should feel physical to the touch—evoking matte injection-molded plastics, subtle molded seamlines, physical screw pockets, and directional control buttons. The interface bridges the gap between hardware housing (cream, ivory, deep crimson) and internal backlit transflective STN LCD digital screens (matrix-tinted panels with double-bordered dialogue chrome).

## Colors
The color system operates on two distinct physical layers: the exterior hardware chassis and the internal sunken LCD matrix display.

- **Primary (Handheld Crimson / #D93636):** Used for exterior chassis accents, primary action clusters (Button A), status banners, and focal callouts. Shaded with `#B51A21` for inset bevels and `#930011` for cast shadows.
- **Secondary (Link Cable Cyan / #146DF4):** Used for auxiliary interactive controls (Button B), digital connectivity indicators, progress gauges, and system badges. Anchored with deep blue `#0055C7` for tactile bevel edges.
- **Tertiary (Pocket Gold / #FBC02D):** Dedicated to critical alert states, save indicators, XP/level counters, and high-value interactive badges. Grounded with `#765700` for shaded outlines.
- **Chassis Shell (Ivory & Cream):** The base hardware body utilizes `#FEF8F7` (highlight), `#F3ECEC` (chassis body), and `#D8D2C2` (recessed housing grooves and seam shadow).
- **LCD Matrix Panel:** Digital screen zones drop into an olive-tinted transflective field with background `#D0C8A8` transitioning to active matrix highlight `#E0E8D0`.
- **Hardware Black / Carbon (#1D1B1B):** Reserved for screen borders, d-pad directional elements, 2px structural pixel-aligned dialogue frames, and 8-bit text display.

## Typography
Typography is split between industrial exterior labeling and in-screen LCD communication:

1. **Hardware Chassis & Headlines:** Rendered in **Space Grotesk**. Used for hardware titles, section anchors, and operational readouts. Bold weights provide structural industrial presence.
2. **Interface Dialogue & Body:** Rendered in **Space Mono**. Replicating monospace character-grid systems of 90s handheld software, this font carries all inventory menus, system logs, dialogue streams, and terminal metadata.
3. **Screen Text Treatment:** Text inside LCD viewport cards should maintain strict casing rules—dialogue and menu headers use uppercase formatting with generous line-height to emulate 8-bit character grid tile spacing.

## Layout & Spacing
The layout follows a physical chassis-enclosure paradigm. The screen area mimics the classic 160x144 pixel ratio (10:9 aspect), framed within responsive containers.

- **Grid Structure:** A 12-column fluid grid on desktop constrained to a max-width of 1080px (simulating a dedicated tabletop battle-station/console dock). Mobile condenses into a single stacked column framed within simulated handheld outer shell padding.
- **Rhythm & Padding:** All spacing aligns strictly to a 4px/8px incremental rhythm. Spacing within LCD dialogue boxes must maintain `space-sm` (8px) internal safe buffers from pixel borders. Component gap layout relies on predictable increments (`space-sm` for related micro-controls, `space-md` for dialogue stack rows).
- **Bezel Ratio:** Center content cards should always establish an explicit bezel clearance: `space-lg` (24px) padding surrounding the core screen surface to emulate molded casing housing.

## Elevation & Depth
Elevation is achieved mechanically via tactile skeletal bevels and sunken LCD chambers rather than blurred atmospheric shadows.

- **Chassis Shell Bevels (Raised):** Interactive physical elements use hard-edged dimensional shadows: top/left highlights (`inset 2px 2px 0px rgba(255, 255, 255, 0.8)`) paired with bottom/right drop ledges (`2px 4px 0px #B51A21` on crimson buttons or `2px 4px 0px #1D1B1B` on neutral chassis surfaces).
- **Sunken LCD Bezel (Recessed):** Screen panels must feel physically depressed under the outer lens. Achieve this via deep inner shadows: `inset 3px 3px 0px rgba(29, 27, 27, 0.4), inset -2px -2px 0px rgba(255, 255, 255, 0.6)`.
- **Dialogue Boxes & Overlays:** Floating menus emulate classic RPG popups: crisp solid 2px black outlines (`#1D1B1B`), flat 4px directional black drop offsets (`4px 4px 0px #1D1B1B`), with no gaussian diffusion.

## Shapes
Handheld molded aesthetics utilize roundedness level `1` (Soft, 0.25rem / 4px base radius) across UI panels, maintaining crisp geometric definition.

- **Exterior Casing:** Chassis outer frames use `rounded-xl` (12px / 0.75rem) to emulate ergonomic handheld plastic palm grips.
- **Tactile Buttons (A/B/Action):** Circular and pill formats with 9999px border-radius, sporting angled 25-degree physical positioning when clustered.
- **LCD Frames & Dialogue Windows:** Sharp rectangular shapes with 4px corner fillets or pure 0px squared corners wrapped in double-line borders with classic RPG 90-degree corner brackets (`+` or inverted corner notched cutouts).

## Components

### 1. Tactile Push Buttons (A, B, Select, Start)
- **Primary Action (A Button):** Circular 48px crimson button (`#D93636`) set in an angled recessed housing. Styled with a hard 3px bottom drop-bevel (`#930011`). Active press state transforms `translate(0, 3px)` with drop-bevel reduced to 0px. Text is uppercase label-md (`#FEF8F7`).
- **Secondary Action (B Button):** Identical structure rendered in link-cable cyan (`#146DF4`) with `#0055C7` depth shadow.
- **Auxiliary (Select/Start):** Angled pill slots (approx. 40px x 12px) set at a -25° slant in charcoal `#1D1B1B`, sunken into the shell with top inset highlights.

### 2. Dialogue & Content Windows (GBC Style)
- Replicating Gen II battle dialogue. White/ivory interior (`#FEF8F7`) surrounded by a distinct double-line frame: an outer 2px solid `#1D1B1B` border, a 2px inner gap, and an inner 1px `#1D1B1B` border.
- Bottom-right corner features an animated blinking downward arrow cursor (8x8px) prompting user interaction.
- Headers are slotted into an overlaid tab attached directly to the top-left border line.

### 3. Chips & Status Badges
- Pill and sharp rectangular badges with solid 1.5px `#1D1B1B` outlines.
- HP/Status variants utilize high-saturation retro fills: Healthy (`#48A253`), Warning/Poison (`#E07828`), Critical (`#D93636`). Text is mono uppercase with letter spacing 0.08em.

### 4. Input Fields
- Recessed screen styling: background tinted `#D0C8A8` (LCD dim) with dark charcoal monospaced text.
- Focus state activates an animated pixel blinking block cursor (`_` or solid `█`) and swaps the outer border to link-cable cyan `#146DF4`.

### 5. Checkboxes & Radio Selectors
- **Checkboxes:** 16x16px square boxes with 2px borders. Unchecked contains blank LCD background; checked fills with a crisp cross icon (`✖`).
- **Radio Buttons:** D-pad directional arrow selectors (`▶`) placed adjacent to the active text row instead of generic circular radio controls.

### 6. Battery & Network Status Indicators
- Top-chassis indicators featuring a simulated physical red LED dot: `#D93636` with a bright center micro-gradient and subtle diffuse outer glow to indicate battery power status.